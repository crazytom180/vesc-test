#pragma once
#include "RC_task.h"
#include "RC_can.h"
#include "RC_tim.h"
#include "RC_m3508.h"
#include "RC_m6020.h"
#include "RC_serial.h"
#include "RC_wave_generator.h"
#include "RC_timer.h"
#include "RC_flysky.h"
#include "RC_cdc.h"
#include "RC_ros_interface.h"
#include "RC_chassis.h"

#include "fdcan.h"
#include "tim.h"


#ifdef __cplusplus

















#endif
#ifdef __cplusplus
extern "C" {
#endif


void All_Init();


	
	
	
	
	
	
	
	
	
	
	
#ifdef __cplusplus
}
#endif