#pragma once
#include "usart.h"
#include <stdio.h>
#include <string.h>


#ifdef __cplusplus













#endif
#ifdef __cplusplus
extern "C" {
#endif

#include <stdarg.h>




int uart_printf(const char *format, ...);



#ifdef __cplusplus
}
#endif