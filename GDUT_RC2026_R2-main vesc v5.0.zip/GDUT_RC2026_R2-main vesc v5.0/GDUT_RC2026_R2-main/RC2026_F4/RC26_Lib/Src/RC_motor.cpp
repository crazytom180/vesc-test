#include "RC_motor.h"

namespace motor
{

	Motor::Motor()
	{
		
	}
	
	
	
	
	
	
}