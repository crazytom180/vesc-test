#pragma once
#include "RC_task.h"
#include "RC_can.h"
#include "RC_tim.h"
#include "RC_m3508.h"
#include "RC_serial.h"
#include "RC_wave_generator.h"
#include "RC_timer.h"
#include "RC_flysky.h"
#include "RC_vesc.h"

#include "can.h"
#include "tim.h"


#ifdef __cplusplus

















#endif
#ifdef __cplusplus
extern "C" {
#endif


void All_Init();


	
	
	
	
	
	
	
	
	
	
	
#ifdef __cplusplus
}
#endif